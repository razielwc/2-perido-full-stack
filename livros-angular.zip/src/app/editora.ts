export class Editora {
  codEditora: number = 0;
  nome: string = '';
}
